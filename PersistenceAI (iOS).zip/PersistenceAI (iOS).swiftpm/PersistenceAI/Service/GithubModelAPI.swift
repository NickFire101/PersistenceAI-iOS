
import Foundation
import SwiftUI

// MARK: - GLOBAL ERROR TYPE (FIXED)
enum APIError: LocalizedError {
    case badURL
    case requestFailed(Int, String)
    case decodingFailed
    case emptyResponse
    
    var errorDescription: String? {
        switch self {
        case .badURL:
            return "Invalid endpoint URL"
        case .requestFailed(let code, let message):
            return "HTTP \(code): \(message)"
        case .decodingFailed:
            return "Failed to decode response"
        case .emptyResponse:
            return "Empty response from server"
        }
    }
}
// MARK: - STREAMING MODELS

private struct StreamResponse: Decodable {
    let choices: [StreamChoice]
}

private struct StreamChoice: Decodable {
    let delta: StreamDelta?
    let finish_reason: String?
}

private struct StreamDelta: Decodable {
    let content: String?
}

// MARK: - MAIN API
final class GitHubModelsAPI {
    // MARK: - STREAMING
    
    private var streamTask: Task<Void, Never>?
    
    func cancelStreaming() {
        streamTask?.cancel()
        streamTask = nil
    }
    
    static let shared = GitHubModelsAPI()
    private init() {}
    
    // MARK: - SEND MESSAGE
    func sendMessage(
        prompt: String,
        chat: ChatSession,
        model: GithubModel,
        apiKey: String,
        endpoint: String,
        systemPrompt: String,
        BehaviorPrompt: String,
        RoboTemp: Double,
        RoboToken: Int,
        imageData: Data? = nil,
        fileData: Data? = nil,
        fileName: String? = nil
    ) async throws -> String {
        
        guard let url = URL(string: endpoint) else {
            throw APIError.badURL
        }
        
        var messages: [[String: Any]] = []
        
        // SYSTEM PROMPTS
        messages.append([
            "role": "system",
            "content": BehaviorPrompt
        ])
        
        messages.append([
            "role": "system",
            "content": systemPrompt
        ])
        
        // CHAT HISTORY (safe limit)
        for msg in chat.messages.suffix(10) {
            messages.append([
                "role": msg.role.rawValue,
                "content": msg.content
            ])
        }
        
        // MARK: - ATTACHMENTS (SAFE MODE)
        var finalPrompt = prompt
        
        // Image (compressed, no base64 spam)
        if let imageData,
           let image = UIImage(data: imageData),
           let compressed = image.jpegData(compressionQuality: 0.25) {
            
            let base64 = compressed.base64EncodedString()
            let trimmed = String(base64.prefix(15_000)) // prevent 413
            
            finalPrompt += """
            
            [IMAGE_DATA]
            \(trimmed)
            """
        }
        
        // File (safe trim)
        if let fileData {
            let base64 = fileData.base64EncodedString()
            let trimmed = String(base64.prefix(15_000))
            
            finalPrompt += """
            
            [FILE_NAME: \(fileName ?? "file")]
            [FILE_DATA]
            \(trimmed)
            """
        }
        
        messages.append([
            "role": "user",
            "content": finalPrompt
        ])
        
        // MARK: - REQUEST BODY
        let body: [String: Any] = [
            "model": model.rawValue,
            "messages": messages,
            "temperature": RoboTemp,
            "max_tokens": RoboToken
        ]
        
        let json = try JSONSerialization.data(withJSONObject: body)
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.httpBody = json
        request.timeoutInterval = 60
        
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        
        // MARK: - RESPONSE
        let (data, response) = try await URLSession.shared.data(for: request)
        
        guard let http = response as? HTTPURLResponse else {
            throw APIError.requestFailed(-1, "No HTTP response")
        }
        
        let rawText = String(data: data, encoding: .utf8) ?? "nil"
        
        print("🔥 STATUS:", http.statusCode)
        print("🔥 RESPONSE:", rawText)
        
        // MARK: - ERROR HANDLING
        guard (200...299).contains(http.statusCode) else {
            throw APIError.requestFailed(http.statusCode, rawText)
        }
        
        guard let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw APIError.decodingFailed
        }
        
        if let error = object["error"] as? [String: Any],
           let message = error["message"] as? String {
            throw APIError.requestFailed(http.statusCode, message)
        }
        
        if let choices = object["choices"] as? [[String: Any]],
           let first = choices.first,
           let message = first["message"] as? [String: Any],
           let content = message["content"] as? String,
           !content.isEmpty {
            return content
        }
        
        throw APIError.emptyResponse
    }
    // MARK: - STREAM MESSAGE
    
    func streamMessage(
        prompt: String,
        chat: ChatSession,
        model: GithubModel,
        apiKey: String,
        endpoint: String,
        systemPrompt: String,
        BehaviorPrompt: String,
        RoboTemp: Double,
        RoboToken: Int,
        imageData: Data? = nil,
        fileData: Data? = nil,
        fileName: String? = nil,
        onToken: @escaping (String) -> Void,
        onComplete: @escaping () -> Void
    ) async throws {
        guard let url = URL(string: endpoint) else {
            throw APIError.badURL
        }
        
        var messages: [[String: Any]] = []
        
        // MARK: - SYSTEM PROMPTS
        
        messages.append([
            "role": "system",
            "content": BehaviorPrompt
        ])
        
        messages.append([
            "role": "system",
            "content": systemPrompt
        ])
        
        // MARK: - CHAT HISTORY
        
        for msg in chat.messages.suffix(10) {
            messages.append([
                "role": msg.role.rawValue,
                "content": msg.content
            ])
        }
        
        // MARK: - USER PROMPT
        
        var finalPrompt = prompt
        
        // Image (same as sendMessage)
        
        if let imageData,
           let image = UIImage(data: imageData),
           let compressed = image.jpegData(compressionQuality: 0.25) {
            
            let base64 = compressed.base64EncodedString()
            let trimmed = String(base64.prefix(15_000))
            
            finalPrompt += """
    
    [IMAGE_DATA]
    \(trimmed)
    """
        }
        
        // File (same as sendMessage)
        
        if let fileData {
            
            let base64 = fileData.base64EncodedString()
            
            let trimmed = String(base64.prefix(15_000))
            
            finalPrompt += """
    
    [FILE_NAME: \(fileName ?? "file")]
    [FILE_DATA]
    \(trimmed)
    """
        }
        
        messages.append([
            "role": "user",
            "content": finalPrompt
        ])
        
        // MARK: - STREAM BODY
        
        let body: [String: Any] = [
            
            "model": model.rawValue,
            
            "messages": messages,
            
            "temperature": RoboTemp,
            
            "max_tokens": RoboToken,
            
            "stream": true
        ]
        
        let json = try JSONSerialization.data(withJSONObject: body)
        
        var request = URLRequest(url: url)
        
        request.httpMethod = "POST"
        
        request.httpBody = json
        
        request.timeoutInterval = 300
        
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        let (bytes, response) = try await URLSession.shared.bytes(for: request)
        
        guard let http = response as? HTTPURLResponse else {
            throw APIError.requestFailed(-1, "No HTTP response")
        }
        
        guard (200...299).contains(http.statusCode) else {
            
            var text = ""
            
            for try await line in bytes.lines {
                text += line
            }
            
            throw APIError.requestFailed(http.statusCode, text)
        }
        // MARK: - STREAM RESPONSE
        
        for try await line in bytes.lines {
            
            if Task.isCancelled {
                break
            }
            
            let trimmed = line.trimmingCharacters(in: .whitespacesAndNewlines)
            
            // Skip empty lines
            
            guard !trimmed.isEmpty else {
                continue
            }
            
            // GitHub/OpenAI streams begin with "data: "
            
            guard trimmed.hasPrefix("data: ") else {
                continue
            }
            
            let payload = String(trimmed.dropFirst(6))
            
            // End of stream
            
            if payload == "[DONE]" {
                break
            }
            
            guard let jsonData = payload.data(using: .utf8) else {
                continue
            }
            
            do {
                
                let chunk = try JSONDecoder().decode(StreamResponse.self, from: jsonData)
                
                if let token = chunk.choices.first?.delta?.content,
                   !token.isEmpty {
                    
                    await MainActor.run {
                        onToken(token)
                    }
                    
                }
                
            } catch {
                
                // Ignore malformed chunks
                continue
                
            }
            
        }
        
        await MainActor.run {
            onComplete()
        }
    }
    
    // MARK: - CHAT TITLE GENERATION (FIXED)
    func generateChatTitle(
        from text: String,
        model: GithubModel,
        apiKey: String,
        endpoint: String
    ) async throws -> String {
        
        guard let url = URL(string: endpoint) else {
            throw APIError.badURL
        }
        
        let messages: [[String: Any]] = [
            [
                "role": "system",
                "content":
"""
You generate chat titles.

STRICT RULES:
- Max 4 words
- No punctuation
- No sentences
- Output ONLY title
- No explanations
- No verbs like "this is"

Example of GOOD:
- SwiftUI Bug Fix
- Image Upload Issue
- Model Picker Design

Example of BAD:
- This chat is about fixing a bug in SwiftUI layout
- </think> I should probably create a short title<think> 
"""
            ],
            [
                "role": "user",
                "content": text
            ]
        ]
        
        let body: [String: Any] = [
            "model": model.rawValue,
            "messages": messages,
            "temperature": 0.3,
            "max_tokens": 20
        ]
        
        let json = try JSONSerialization.data(withJSONObject: body)
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.httpBody = json
        
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        
        let (data, response) = try await URLSession.shared.data(for: request)
        
        guard let http = response as? HTTPURLResponse else {
            throw APIError.requestFailed(-1, "No response")
        }
        
        let raw = String(data: data, encoding: .utf8) ?? "nil"
        print("🔥 TITLE STATUS:", http.statusCode)
        print("🔥 TITLE RESPONSE:", raw)
        
        let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any]
        let choices = object?["choices"] as? [[String: Any]]
        let message = choices?.first?["message"] as? [String: Any]
        
        return (message?["content"] as? String)?
            .trimmingCharacters(in: .whitespacesAndNewlines)
        ?? "New Chat"
    }
}
