import SwiftUI
import Combine

@main
struct PersistenceAIApp: App {
    var body: some Scene {
        WindowGroup {
            RootView()
        }
    }
}
