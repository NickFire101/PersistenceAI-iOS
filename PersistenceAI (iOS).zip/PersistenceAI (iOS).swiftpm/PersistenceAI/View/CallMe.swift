//
//  PersistenceAI.swift
//  Full Single File SwiftUI AI App
//  CMS
//

import SwiftUI
import UniformTypeIdentifiers
import PhotosUI
import Foundation
import Combine
import UIKit

// MARK: - ROOT VIEW
struct RootView: View {
    
    @StateObject private var state = AppState()
    @State var lightMode: Bool = false
    @State var BehaviorPrompt: String = ""
    @State var RoboTemp: Double = 0.8
    @State var RoboToken: Int = 2048
    
    var body: some View {
        
        NavigationSplitView {
            
            SidebarView()
                .environmentObject(state)
            
        } detail: {
            
           MainTabsView(lightMode: $lightMode,
           BehaviorPrompt: $BehaviorPrompt, 
           RoboTemp: $RoboTemp,
           RoboToken: $RoboToken
            )
                .environmentObject(state)
        }
    }
}

