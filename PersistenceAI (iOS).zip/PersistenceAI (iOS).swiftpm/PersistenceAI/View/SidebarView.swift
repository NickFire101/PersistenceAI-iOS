import SwiftUI

struct SidebarView: View {
    @EnvironmentObject var state: AppState
    
    @State private var renameText: String = ""
    
    @State private var selectedRenameChat: ChatSession?
    
    
    var body: some View {
        
        List(selection: $state.selectedChatID) {
            
            Section {
                
                Button {
                    
                    state.createChat()
                    
                } label: {
                    
                    Label(
                        "Chat",
                        systemImage: "plus.bubble.fill"
                    )
                }
                
            }
            
            Section("Chats") {
                
                ForEach(state.chats) { chat in
                    
                    NavigationLink(
                        value: chat.id
                    ) {
                        
                        VStack(alignment: .leading) {
                            
                            Text(chat.title)
                                .font(.headline)
                            
                            Text(
                                "\(chat.messages.count) messages"
                            )
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        }
                    }
                    .contextMenu {
                        
                        Button("Rename") {
                            
                            selectedRenameChat = chat
                            renameText = chat.title
                        }
                        
                        Button(
                            "Delete",
                            role: .destructive
                        ) {
                            
                            state.deleteChat(chat)
                        }
                    }
                }
            }
        }
        .sheet(item: $selectedRenameChat) { chat in
            
            NavigationStack {
                
                Form {
                    
                    TextField(
                        "",
                        text: $renameText
                    )
                    
                    Button("Save") {
                        
                        state.renameChat(
                            chat,
                            title: renameText
                        )
                        
                        selectedRenameChat = nil
                    }
                }
                .navigationTitle("Rename Chat")
            }
        }
        .navigationTitle("PersistenceAI")
    }
}

