import SwiftUI
import Combine

struct MainTabsView: View {
    
    @Binding var lightMode: Bool
    @Binding var BehaviorPrompt: String
    @Binding var RoboTemp: Double
    @Binding var RoboToken: Int
    
    var body: some View {
        TabView {
            
            // AI TAB
            AIView()
                .tabItem {
                    Label("AI", systemImage: "sparkles")
                }
                .tag(0)
            
            // SETTINGS TAB
            SettingsView(
                lightMode: $lightMode,
                behaviorPrompt: $BehaviorPrompt,
                roboTemp: $RoboTemp,
                roboToken: $RoboToken
            )
            .tabItem {
                Label("Settings", systemImage: "gear")
            }
            .tag(1)
        }
        .preferredColorScheme(lightMode ? .light : .dark)
    }
}
