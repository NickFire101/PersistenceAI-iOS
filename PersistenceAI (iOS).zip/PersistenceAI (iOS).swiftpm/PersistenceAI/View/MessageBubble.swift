import SwiftUI
import Combine

struct MessageBubble: View {
    
    let message: ChatMessage
    
    var body: some View {
        
        HStack {
            
            if message.role == .assistant {
                
                bubble
                
                Spacer()
                
            } else {
                
                Spacer()
                
                bubble
            }
        }
    }
    
    var bubble: some View {
        
        VStack(alignment: .leading, spacing: 8) {
            
            HStack {
                
                Image(
                    systemName:
                        message.role == .assistant
                    ? "apple.intelligence"
                    : "person.fill"
                )
                
                Text(
                    message.role == .assistant
                    ? "PersistenceAI"
                    : "You"
                )
                .font(.caption.bold())
                
                Spacer()
                
                Text(
                    message.timestamp.formatted(
                        date: .omitted,
                        time: .shortened
                    )
                )
                .font(.caption2)
            }
                MessageContentView(content: message.content)
            
            HStack {
                
                Spacer()
                
                Button {
                    
#if os(iOS)            
                    UIPasteboard.general.string =
                    message.content
#endif                  
                } label: {
                    
                    Image(systemName: "doc.on.doc")
                }
            }
        }
        .padding()
        .frame(maxWidth: 330)
        .background(
            
            RoundedRectangle(cornerRadius: 18)
                .fill(
                    message.role == .assistant
                    ? Color.gray.opacity(0.18)
                    : Color.blue.opacity(0.22)
                )
        )
    }
}
