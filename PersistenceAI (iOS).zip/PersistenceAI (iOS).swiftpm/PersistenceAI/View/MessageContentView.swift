import SwiftUI
import HighlightSwift

struct MessageContentView: View {
    
    let content: String
    
    var body: some View {
        
        VStack(alignment: .leading, spacing: 12) {
            
            ForEach(parseBlocks(), id: \.id) { block in
                
                switch block.type {
                    
                
                case .text:
                    
                    TextBlockView(text: block.content)
                    
                case .code:
                    
                    CodeBlockView(
                        code: block.content,
                        language: block.language
                    )
                    
                case .think:
                    
                    ThinkBlockView(
                        thoughts: block.content
                    )
                }
            }
        }
    }
    
    func parseBlocks() -> [ContentBlock] {
        
        var blocks: [ContentBlock] = []
        
        let pattern = #"<think>([\s\S]*?)</think>|```(\w+)?\n([\s\S]*?)```"#
        
        guard let regex = try? NSRegularExpression(pattern: pattern) else {
            return [
                ContentBlock(
                    type: .text,
                    content: content
                )
            ]
        }
        
        let nsString = content as NSString
        
        var lastLocation = 0
        
        let matches = regex.matches(
            in: content,
            range: NSRange(
                location: 0,
                length: nsString.length
            )
        )
        
        for match in matches {
            
            let range = match.range
            
            // Normal text before this block
            if range.location > lastLocation {
                
                let text = nsString.substring(
                    with: NSRange(
                        location: lastLocation,
                        length: range.location - lastLocation
                    )
                )
                
                let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
                
                if !trimmed.isEmpty {
                    blocks.append(
                        ContentBlock(
                            type: .text,
                            content: trimmed
                        )
                    )
                }
            }
            
            // <think>...</think>
            if match.range(at: 1).location != NSNotFound {
                
                let thoughts = nsString.substring(
                    with: match.range(at: 1)
                )
                
                blocks.append(
                    ContentBlock(
                        type: .think,
                        content: thoughts.trimmingCharacters(in: .whitespacesAndNewlines)
                    )
                )
            }
            
            // ```code```
            else {
                
                let language: String
                
                if match.range(at: 2).location != NSNotFound {
                    language = nsString.substring(with: match.range(at: 2))
                } else {
                    language = "Code"
                }
                
                let code = nsString.substring(
                    with: match.range(at: 3)
                )
                
                blocks.append(
                    ContentBlock(
                        type: .code,
                        content: code,
                        language: language
                    )
                )
            }
            
            lastLocation = range.location + range.length
        }
        
        // Remaining text
        if lastLocation < nsString.length {
            
            let text = nsString.substring(from: lastLocation)
            
            let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
            
            if !trimmed.isEmpty {
                
                blocks.append(
                    ContentBlock(
                        type: .text,
                        content: trimmed
                    )
                )
            }
        }
        
        // If nothing matched
        if blocks.isEmpty {
            
            blocks.append(
                ContentBlock(
                    type: .text,
                    content: content
                )
            )
        }
        
        return blocks
    }
}

struct ContentBlock {
    
    let id = UUID()
    
    let type: BlockType
    
    let content: String
    
    var language: String = ""
}

struct CodeBlockView: View {
    
    let code: String
    let language: String
    
    var body: some View {
        
        VStack(spacing: 0) {
            
            HStack {
                
                Text(language.uppercased())
                    .font(.caption.bold())
                
                Spacer()
                
                Button {
                    
#if os(iOS)
                    UIPasteboard.general.string = code
#endif
                    
                } label: {
                    
                    Image(systemName: "doc.on.doc")
                }
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            
            Divider()
            
            ScrollView(.horizontal) {
                
                CodeText(
                    code,
                    language: language.isEmpty ? "plaintext" : language
                )
                .theme(.xcode)
                .codeFont(
                    .system(
                        .body,
                        design: .monospaced
                    )
                )
                .showBackground(false)
                .codePadding(12)
                .textSelection(.enabled)
                
                
                
                    .frame(
                        maxWidth: .infinity,
                        alignment: .leading
                    )
                
                    .padding()
                    .textSelection(.enabled)
            }
        }
        .background(
            RoundedRectangle(
                cornerRadius: 14
            )
            .fill(
                Color.black.opacity(0.08)
            )
        )
    }
}
struct TextBlockView: View {
    
    let text: String
    
    @StateObject
    private var detector = ImageDetector()
    var body: some View {
        
        
        VStack(alignment: .leading, spacing: 8) {
            
            ForEach(lines, id: \.self) { line in
                
                if let url = URL(string: line) {
                    
                    Group {
                        
                        if detector.isImage {
                            
                            AsyncImage(url: url) { image in
                                image.resizable()
                            } placeholder: {
                                ProgressView()
                            }
                            
                        } else {
                            
                            Text(line)
                            
                        }
                        
                    }
                    .onAppear {
                        print("LINE:", line)
                    }
                    
                    .onAppear {
                        detector.check(url)
                    }
                    
                } else {
                    
                    Text(line)
                    
                }
                
            }
            
        }
        
    }
    
    private var lines: [String] {
        text.components(separatedBy: .newlines)
            .filter { !$0.isEmpty }
    }
    
    private func isImageURL(_ string: String) -> Bool {
        
        let lower = string.lowercased()
        
        return lower.hasSuffix(".png")
        || lower.hasSuffix(".jpg")
        || lower.hasSuffix(".jpeg")
        || lower.hasSuffix(".gif")
        || lower.hasSuffix(".webp")
        || lower.hasSuffix(".heic")
    }
    
}
