import SwiftUI

struct AIView: View {
    
    @EnvironmentObject var state: AppState
    
    @State private var input: String = ""
    @State private var scrollProxy: ScrollViewProxy?
    @State var greeting: String = "Ready when you are!"
    
    var body: some View {
        VStack(spacing: 0) {
            messagesView
            Divider()
            inputBar
        }
    }
    // MARK: - MESSAGES
    var messagesView: some View {
        VStack{
            
            if let fchat = state.selectedChat {
                
                if fchat.messages.isEmpty {
                  Spacer()  
                 Text("\(greeting)")   
                        .font(.largeTitle)
                        
                    Spacer()
                }else {
                    ScrollViewReader { proxy in
                        ScrollView {
                            LazyVStack(spacing: 12) {
                                
                                if let chat = state.selectedChat {
                                    ForEach(chat.messages) { msg in
                                        MessageBubble(message: msg)
                                            .id(msg.id)
                                    }
                                }
                                
                                if state.isThinking {
                                    ThinkingIndicator()
                                }
                            }
                            .padding()
                        }
                        
                        .onAppear {
                            scrollProxy = proxy
                        }
                    }
                }
        }
        }
    }
    
    // MARK: - MODEL PICKER
    var modelPicker: some View {
        Menu {
            ForEach(GithubModel.allCases) { model in
                Button {
                    state.selectedModel = model
                } label: {
                    Label(model.displayName, systemImage: model.icon)
                }
            }
        } label: {
            HStack(spacing: 6) {
                Image(systemName: state.selectedModel.icon)
                Text(state.selectedModel.displayName)
                    .font(.caption)
                Image(systemName: "chevron.down")
                    .font(.caption2)
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .background(.thinMaterial)
            .clipShape(Capsule())
        }
    }
    
    // MARK: - INPUT BAR
    var inputBar: some View {
            
            HStack(spacing: 10) {
                
                modelPicker
                
                TextField("Start shipping small...", text: $input)
                    .padding(10)
                    .background(.thinMaterial)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                
                Button {
                    Task { await sendMessage() }
                } label: {
                    Image(systemName: "arrow.up.circle.fill")
                        .font(.title2)
                }
                
            }
            
            .padding()
    }
    
    // MARK: - SEND MESSAGE
    func sendMessage() async {
        
        let clean = input.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty else { return }
        
        // User message
        let userMessage = ChatMessage(role: .user, content: clean)
        state.selectedChat?.messages.append(userMessage)
        
        input = ""
        autoScroll()
        
        // Generate title only for the first user message
        if state.selectedChat?.messages.count == 1 {
            
            Task {
                do {
                    
                    let title = try await GitHubModelsAPI.shared.generateChatTitle(
                        from: clean,
                        model: state.selectedModel,
                        apiKey: state.apiKey,
                        endpoint: state.endpoint
                    )
                    
                    await MainActor.run {
                        state.selectedChat?.title = title
                        state.saveChats()
                    }
                    
                } catch {
                    
                    await MainActor.run {
                        state.selectedChat?.title = String(clean.prefix(25))
                        state.saveChats()
                    }
                    
                }
            }
            
        }
        
        state.isThinking = true
        
        // Empty assistant message
        let assistantMessage = ChatMessage(
            role: .assistant,
            content: "",
            isStreaming: true
        )
        
        state.selectedChat?.messages.append(assistantMessage)
        
        autoScroll()
        
        guard let assistantIndex = state.selectedChat?.messages.indices.last,
              let chat = state.selectedChat else {
            state.isThinking = false
            return
        }
        
        do {
            
            try await GitHubModelsAPI.shared.streamMessage(
                prompt: clean,
                chat: chat,
                model: state.selectedModel,
                apiKey: state.apiKey,
                endpoint: state.endpoint,
                systemPrompt: state.systemPrompt,
                BehaviorPrompt: state.BehaviorPrompt,
                RoboTemp: state.RoboTemp,
                RoboToken: state.RoboToken,
                
                onToken: { token in
                    
                    Task { @MainActor in
                        
                        guard let chat = state.selectedChat,
                              assistantIndex < chat.messages.count else {
                            return
                        }
                        
                        state.selectedChat?.messages[assistantIndex].content += token
                        autoScroll()
                        
                    }
                    
                },
                
                onComplete: {
                    
                    Task { @MainActor in
                        
                        guard let chat = state.selectedChat,
                              assistantIndex < chat.messages.count else {
                            return
                        }
                        
                        state.selectedChat?.messages[assistantIndex].isStreaming = false
                        
                        state.isThinking = false
                        state.saveChats()
                        
                        autoScroll()
                        
                    }
                    
                }
                
            )
            
        } catch {
            
            await MainActor.run {
                
                state.isThinking = false
                
                if let chat = state.selectedChat,
                   assistantIndex < chat.messages.count,
                   chat.messages[assistantIndex].content.isEmpty {
                    
                    state.selectedChat?.messages.remove(at: assistantIndex)
                    
                }
                
            }
            
        }
        
    }
    
    // MARK: - SCROLL
    func autoScroll() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) {
            if let last = state.selectedChat?.messages.last {
                scrollProxy?.scrollTo(last.id, anchor: .bottom)
            }
        }
    }
}
