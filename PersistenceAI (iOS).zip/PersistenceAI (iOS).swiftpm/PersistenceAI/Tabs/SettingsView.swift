import SwiftUI
import UIKit
import UniformTypeIdentifiers
import PassKit

// MARK: - EXPORT MODEL

struct PersistenceAIExport: Codable {
    var chats: [ChatSession]
    var selectedModel: String
    var apiKey: String
    var endpoint: String
    var behaviorPrompt: String
    var temperature: Double
    var token: Int
    var timestamp: Date
}

// MARK: - SHARE SHEET

struct ShareSheet: UIViewControllerRepresentable {
    var items: [Any]
    
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}

// MARK: - VERSION HELPER

extension UIApplication {
    static func appVersion() -> String {
        Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "Unknown"
    }
}

// MARK: - APPLE PAY MANAGER (INLINE)

final class ApplePayManager: NSObject, ObservableObject, PKPaymentAuthorizationControllerDelegate {
    
    @Published var isProcessing = false
    
    private let merchantID = "merchant.com.persistenceai.app"
    private let countryCode = "PH"
    private let currencyCode = "PHP"
    
    func startPayment(amount: Double, description: String) {
        
        guard PKPaymentAuthorizationController.canMakePayments() else {
            print("Apple Pay not available")
            return
        }
        
        let request = PKPaymentRequest()
        request.merchantIdentifier = merchantID
        request.countryCode = countryCode
        request.currencyCode = currencyCode
        request.merchantCapabilities = .threeDSecure
        request.supportedNetworks = [.visa, .masterCard, .amex]
        
        request.paymentSummaryItems = [
            PKPaymentSummaryItem(
                label: description,
                amount: NSDecimalNumber(value: amount)
            )
        ]
        
        let controller = PKPaymentAuthorizationController(paymentRequest: request)
        controller.delegate = self
        
        controller.present { success in
            if !success {
                print("An error ocurred, pls try again...")
            }
        }
    }
    
    // MARK: Delegate
    
    func paymentAuthorizationControllerDidFinish(_ controller: PKPaymentAuthorizationController) {
        controller.dismiss()
        isProcessing = false
    }
    
    func paymentAuthorizationController(
        _ controller: PKPaymentAuthorizationController,
        didAuthorizePayment payment: PKPayment,
        handler completion: @escaping (PKPaymentAuthorizationResult) -> Void
    ) {
        print("Payment token:", payment.token)
        completion(PKPaymentAuthorizationResult(status: .success, errors: nil))
    }
}

// MARK: - SETTINGS VIEW

struct SettingsView: View {
    
    @EnvironmentObject var state: AppState
    
    @Binding var lightMode: Bool
    @Binding var behaviorPrompt: String
    @Binding var roboTemp: Double
    @Binding var roboToken: Int
    
    @StateObject private var applePay = ApplePayManager()
    
    @State private var showShare = false
    @State private var exportURL: URL?
    
    @State private var showImporter = false
    @State private var showError = false
    @State private var errorMessage = ""
    
    var body: some View {
        NavigationStack {
            Form {
                
                // MARK: Info
                Section("Info") {
                    Text("""
PersistenceAI is a(n) core framework AI build by OneCloud Developers, and models imported from ODCA (OneCloud Developer Cloud Agents), you can register an API from PersistenceAI (For Developers).
""")
                }
                
                // MARK: Payment (NEW)
                Section("Payment") {
                    Text("Pay to get more credits! Plus edit models or create models!")
                    Button {
                        applePay.startPayment(
                            amount: 49.0,
                            description: "PersistenceAI Pro Access"
                        )
                    } label: {
                        HStack {
                            Image(systemName: "creditcard")
                            Text("Pay")
                        }
                        
                    }
                    .disabled(!PKPaymentAuthorizationController.canMakePayments())
                }
                
                // MARK: Data
                Section("Data Management") {
                    Button("Export Data") {
                        exportData()
                    }
                    
                    Button("Import Data") {
                        showImporter = true
                    }
                }
                
                // MARK: Version
                Section("Version") {
                    Text("App Version: \(UIApplication.appVersion())")
                    Text("AI Version: PersistenceAI 100.000.063")
                    Text("Model: AE339803201")
                }
                
                // MARK: System
                Section("System") {
                    Toggle("Light Mode", isOn: $lightMode)
                }
                
                // MARK: AI Preferences
                Section("AI Preference") {
                    TextField("Prompt", text: $behaviorPrompt)
                    
                    TextField("Temperature", value: $roboTemp, format: .number)
                        .keyboardType(.decimalPad)
                    
                    TextField("Token", value: $roboToken, format: .number)
                        .keyboardType(.numberPad)
                }
            }
            .navigationTitle("Settings")
            
            // IMPORT
            .fileImporter(
                isPresented: $showImporter,
                allowedContentTypes: [UTType.json],
                allowsMultipleSelection: false
            ) { result in
                importData(result)
            }
            
            // SHARE
            .sheet(isPresented: $showShare) {
                if let url = exportURL {
                    ShareSheet(items: [url])
                }
            }
            
            // ERROR
            .alert("Import Failed", isPresented: $showError) {
                Button("OK", role: .cancel) {}
            } message: {
                Text(errorMessage)
            }
        }
    }
}

// MARK: - LOGIC

extension SettingsView {
    
    // EXPORT
    func exportData() {
        let payload = PersistenceAIExport(
            chats: state.chats,
            selectedModel: "\(state.selectedModel)",
            apiKey: state.apiKey,
            endpoint: state.endpoint,
            behaviorPrompt: behaviorPrompt,
            temperature: roboTemp,
            token: roboToken,
            timestamp: Date()
        )
        
        do {
            let encoder = JSONEncoder()
            encoder.dateEncodingStrategy = .iso8601
            
            let data = try encoder.encode(payload)
            
            let url = FileManager.default.temporaryDirectory
                .appendingPathComponent("PersistenceAI_Export.json")
            
            try data.write(to: url, options: .atomic)
            
            exportURL = url
            showShare = true
            
        } catch {
            errorMessage = "Export error: \(error.localizedDescription)"
            showError = true
        }
    }
    
    // IMPORT
    func importData(_ result: Result<[URL], Error>) {
        do {
            guard let url = try result.get().first else { return }
            
            let access = url.startAccessingSecurityScopedResource()
            defer {
                if access { url.stopAccessingSecurityScopedResource() }
            }
            
            let data = try Data(contentsOf: url)
            
            let decoder = JSONDecoder()
            decoder.dateDecodingStrategy = .iso8601
            
            let decoded = try decoder.decode(PersistenceAIExport.self, from: data)
            
            DispatchQueue.main.async {
                state.chats = decoded.chats
                behaviorPrompt = decoded.behaviorPrompt
                roboTemp = decoded.temperature
                roboToken = decoded.token
            }
            
        } catch {
            errorMessage = error.localizedDescription
            showError = true
        }
    }
}

