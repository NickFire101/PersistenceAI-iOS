import SwiftUI
import Foundation

enum StreamState {
    case idle
    case connecting
    case streaming
    case finished
    case cancelled
    case failed(Error)
}
