import SwiftUI
import Foundation
import UniformTypeIdentifiers

// MARK: - Attachment Type

enum AttachmentType: String, Codable {
    case image
    case file
}

// MARK: - Chat Attachment

struct ChatAttachment: Codable, Identifiable, Hashable {
    
    let id: UUID
    
    let type: AttachmentType
    
    let fileName: String
    
    let mimeType: String
    
    /// Base64 image data (without processing)
    var imageBase64: String?
    
    /// Text extracted from documents
    var textContent: String?
    
    init(
        id: UUID = UUID(),
        type: AttachmentType,
        fileName: String,
        mimeType: String,
        imageBase64: String? = nil,
        textContent: String? = nil
    ) {
        
        self.id = id
        self.type = type
        self.fileName = fileName
        self.mimeType = mimeType
        self.imageBase64 = imageBase64
        self.textContent = textContent
    }
}

// MARK: - Helpers

extension ChatAttachment {
    
    static func image(
        fileName: String,
        data: Data,
        mimeType: String = "image/jpeg"
    ) -> ChatAttachment {
        
        ChatAttachment(
            type: .image,
            fileName: fileName,
            mimeType: mimeType,
            imageBase64: "data:\(mimeType);base64,\(data.base64EncodedString())"
        )
    }
    
    static func file(
        fileName: String,
        text: String,
        mimeType: String = "text/plain"
    ) -> ChatAttachment {
        
        ChatAttachment(
            type: .file,
            fileName: fileName,
            mimeType: mimeType,
            textContent: text
        )
    }
}

// MARK: - Supported File Types

extension ChatAttachment {
    
    static let supportedTypes: [UTType] = [
        
        // Images
        .png,
        .jpeg,
        .heic,
        .image,
        .tiff,
        .applicationBundle,
        .audio,
        .folder,
        .data,
        .mp3,
        .mpeg,
        .livePhoto,
        .movie,
        .png,
        .plainText,
        .text,
        .sourceCode,
        .json,
        .xml,
        .html,
        .pdf
    ]
}

