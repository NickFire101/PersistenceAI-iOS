import SwiftUI
import UIKit
import Combine

@MainActor
final class ImageDetector: ObservableObject {
    
    @Published var isImage = false
    
    func check(_ url: URL) {
        
        var request = URLRequest(url: url)
        request.httpMethod = "HEAD"
        
        URLSession.shared.dataTask(with: request) { _, response, _ in
            
            guard
                let response = response as? HTTPURLResponse,
                let type = response.value(forHTTPHeaderField: "Content-Type")
            else {
                return
            }
            
            DispatchQueue.main.async {
                self.isImage = type.starts(with: "image/")
            }
        
        }.resume()
    }
    
}
