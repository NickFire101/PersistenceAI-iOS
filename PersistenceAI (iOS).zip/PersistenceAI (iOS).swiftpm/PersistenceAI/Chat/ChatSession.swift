import SwiftUI
import Combine

struct ChatSession: Codable, Identifiable {
    
    let id: UUID
    
    var title: String
    
    var messages: [ChatMessage]
    
    
    
    init(
        id: UUID = UUID(),
        title: String,
        messages: [ChatMessage]
    ) {
        
        self.id = id
        self.title = title
        self.messages = messages
    }
}
