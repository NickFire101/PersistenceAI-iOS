import Foundation

struct ChatMessage: Codable, Identifiable, Hashable {
    
    let id: UUID
    
    var role: MessageRole
    
    var content: String
    
    /// True while the AI is still generating this message.
    var isStreaming: Bool
    
    var timestamp: Date
    
    init(
        id: UUID = UUID(),
        role: MessageRole,
        content: String,
        isStreaming: Bool = false,
        timestamp: Date = Date()
    ) {
        
        self.id = id
        self.role = role
        self.content = content
        self.isStreaming = isStreaming
        self.timestamp = timestamp
    }
    
    // MARK: - Codable
    
    enum CodingKeys: String, CodingKey {
        case id
        case role
        case content
        case isStreaming
        case timestamp
    }
    
    init(from decoder: Decoder) throws {
        
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        id = try container.decodeIfPresent(UUID.self, forKey: .id) ?? UUID()
        
        role = try container.decode(MessageRole.self, forKey: .role)
        
        content = try container.decodeIfPresent(String.self, forKey: .content) ?? ""
        
        // Default to false so older saved chats still decode.
        isStreaming = try container.decodeIfPresent(Bool.self, forKey: .isStreaming) ?? false
        
        timestamp = try container.decodeIfPresent(Date.self, forKey: .timestamp) ?? Date()
    }
    
    func encode(to encoder: Encoder) throws {
        
        var container = encoder.container(keyedBy: CodingKeys.self)
        
        try container.encode(id, forKey: .id)
        try container.encode(role, forKey: .role)
        try container.encode(content, forKey: .content)
        try container.encode(isStreaming, forKey: .isStreaming)
        try container.encode(timestamp, forKey: .timestamp)
    }
}
