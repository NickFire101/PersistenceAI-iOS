import SwiftUI

enum GithubModel: String, Codable, CaseIterable, Identifiable {
    
    var id: String { rawValue }
    
    case Flash  = "gpt-4.1-mini"
    case Mini   = "Phi-4-multimodal-instruct"
 //   case Hermes = "DeepSeek-r1"
    case Omega  = "gpt-4o-mini"
    case Pro    = "mistral-medium-2505"
    case CodeV  = "Codestral-2501"
    case Ultra  = "cohere-command-a"
    
    var displayName: String {
        switch self {
            
        case .Flash:
            return "Flash"
            
        case .Mini:
            return "Mini"
            
       /* case .Hermes:
            return "Hermes"*/
            
        case .Omega:
            return "Omega"
            
        case .Pro:
            return "Pro"
            
        case .CodeV:
            return "CodeV"
            
        case .Ultra:
            return "Ultra"
        }
    }
    
    var category: String {
        switch self {
            
        case .Flash:
            return "PersistenceAI Flash"
            
        case .Mini:
            return "PersistenceAI Mini"
            
        /*case .Hermes:
            return "PersistenceAI Hermes"*/
            
        case .Omega:
            return "PersistenceAI Omega"
            
        case .Pro:
            return "PersistenceAI Pro"
            
        case .CodeV:
            return "PersistenceAI CodeV"
            
        case .Ultra:
            return "PersistenceAI Ultra"
        }
    }
    
    var subtitle: String {
        switch self {
            
        case .Flash:
            return "Fast & Intelligent"
            
        case .Mini:
            return "Compact Multimodal"
            
     /*   case .Hermes:
            return "Advanced Reasoning" */
            
        case .Omega:
            return "Open Foundation Model"
            
        case .Pro:
            return "Professional Assistant"
            
        case .CodeV:
            return "Programming Expert"
            
        case .Ultra:
            return "Flagship Experience"
        }
    }
    
    var icon: String {
        switch self {
            
        case .Flash:
            return "bolt.fill"
            
        case .Mini:
            return "circle.grid.2x2.fill"
            
       /* case .Hermes:
            return "brain" */
            
        case .Omega:
            return "globe"
            
        case .Pro:
            return "apple.intelligence"
            
        case .CodeV:
            return "terminal.fill"
            
        case .Ultra:
            return "sparkles"
        }
    }
}
