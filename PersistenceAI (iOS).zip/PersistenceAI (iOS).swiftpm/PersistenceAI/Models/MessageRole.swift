import SwiftUI

enum MessageRole: String, Codable {
    
    case user
    case assistant
}
