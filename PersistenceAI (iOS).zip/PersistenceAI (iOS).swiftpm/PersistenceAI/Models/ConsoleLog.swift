import SwiftUI
import Combine

struct ConsoleLog: Identifiable {
    let id = UUID()
    let text: String
    let date: Date
}
