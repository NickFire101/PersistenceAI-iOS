import SwiftUI

struct APIModel: Codable {
    let id: String
}
