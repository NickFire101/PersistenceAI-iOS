import SwiftUI
import Combine

enum BlockType {
    case text
    case code
    case think
}
