import SwiftUI
import Combine

struct ThinkBlockView: View {
    
    let thoughts: String
    
    @State private var expanded = false
    
    var body: some View {
        
        VStack(alignment: .leading, spacing: 10) {
            
            Button {
                
                withAnimation(.easeInOut) {
                    expanded.toggle()
                }
                
            } label: {
                
                HStack {
                    
                    Image(systemName:
                            expanded
                          ? "brain.head.profile.fill"
                          : "brain.head.profile"
                    )
                    
                    Text(
                        expanded
                        ? "Hide My Thinking"
                        : "Show My Thinking"
                    )
                    
                    Spacer()
                    
                    Image(systemName:
                            expanded
                          ? "chevron.up"
                          : "chevron.down"
                    )
                }
                .font(.subheadline.weight(.semibold))
            }
            .buttonStyle(.plain)
            
            if expanded {
                
                ScrollView([.horizontal, .vertical], showsIndicators: true) {
                    
                    Text(thoughts)
                        .font(.system(.footnote, design: .monospaced))
                        .foregroundStyle(.secondary)
                        .textSelection(.enabled)
                        .fixedSize(horizontal: true, vertical: true)
                        .padding(12)
                }
                .frame(minHeight: 80, maxHeight: 300)
                .background(.gray.opacity(0.12))
                .clipShape(
                    RoundedRectangle(cornerRadius: 10)
                )
                .transition(
                    .opacity.combined(with: .move(edge: .top))
                )
            }
        }
    }
}
