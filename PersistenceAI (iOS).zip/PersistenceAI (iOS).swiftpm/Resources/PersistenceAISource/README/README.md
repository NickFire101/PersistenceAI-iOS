# PersistenceAI

PersistenceAI is a next-generation AI assistant built with SwiftUI, designed to provide intelligent conversations, multimodal file analysis, image understanding, document processing, and extensible AI workflows.

## Features

* 🤖 AI-powered chat assistant
* 📷 Image analysis and vision support
* 📄 Document reading and summarization
* 📁 File import and management
* 💬 Conversation history persistence
* 🔍 Search and knowledge retrieval
* ⚡ Native SwiftUI interface
* 🔒 Secure API key management
* 🧩 Modular architecture
* 📱 iPhone, iPad, and macOS support

## Screenshots

Add screenshots here.

## Requirements

* Xcode 16+
* iOS 18+
* macOS 15+
* Swift 6+

## Installation

### Clone Repository

```bash
git clone https://github.com/OneCloudDevelopers/PersistenceAI.git
cd PersistenceAI
```

### Open Project

```bash
open PersistenceAI.xcodeproj
```

### Configure API

Create a configuration file and add your credentials:

```swift
enum APIConfig {
    static let githubPAT = "YOUR_GITHUB_PAT"
    static let endpoint = "YOUR_ENDPOINT"
    static let model = "YOUR_MODEL"
}
```

## Quick Start

1. Launch the application.
2. Configure your AI endpoint.
3. Start a conversation.
4. Upload files or images.
5. Receive AI-powered responses.

## Project Structure

```text
PersistenceAI
├── App
├── Models
├── Services
├── Views
├── Components
├── Persistence
├── Utilities
└── Resources
```

## Vision Support

PersistenceAI supports multimodal AI models capable of:

* Reading images
* Understanding screenshots
* Analyzing diagrams
* Extracting text from images
* Processing visual content

## File Support

Supported formats:

* PDF
* TXT
* JSON
* Markdown
* Images
* CSV
* Source Code Files

## Security

Never commit:

* API Keys
* Personal Access Tokens
* Private Endpoints
* User Data

Use environment variables or secure storage whenever possible.

## Contributing

Contributions are welcome.

1. Fork the repository.
2. Create a feature branch.
3. Commit changes.
4. Submit a pull request.

## Roadmap

### Phase 1

* Core Chat
* Persistent History
* File Uploads

### Phase 2

* Vision Models
* Memory System
* Advanced Search

### Phase 3

* Multi-Agent Workflows
* Plugin System
* Cloud Synchronization

### Phase 4

* Enterprise Features
* Team Collaboration
* Custom AI Deployments

## License

This project is licensed under the MIT License.

See the LICENSE file for details.

## Authors

OneCloud Developers

## Disclaimer

PersistenceAI is provided "AS IS" without warranty of any kind. Users are responsible for complying with the terms of service of any AI provider, API provider, or third-party service used with this software.

