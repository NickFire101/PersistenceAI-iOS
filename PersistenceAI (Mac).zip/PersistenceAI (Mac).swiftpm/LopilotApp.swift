import SwiftUI

@main
struct PersistenceAIApp: App {
    var body: some Scene {
        let _ = AppTracker.shared // Start monitoring apps
        
        WindowGroup {
            ContentView()
                .frame(minWidth: 645, minHeight: 645)
        }
    }
}
