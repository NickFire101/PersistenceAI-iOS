import SwiftUI
#if canImport(AppKit)
import AppKit
#endif

class AppTracker {
    static let shared = AppTracker()
    var lastActiveApp: String = "a macOS application"

    init() {
        // Watch for whenever the user switches apps
#if os(MacOS)
        NSWorkspace.shared.notificationCenter.addObserver(
            forName: NSWorkspace.didActivateApplicationNotification,
            object: nil,
            queue: .main
        ) { notification in
            if let app = notification.userInfo?[NSWorkspace.applicationUserInfoKey] as? NSRunningApplication,
               let name = app.localizedName,
               // Ignore Lopilot and Finder so we keep the "Work" app in memory
               name != "PersistenceAI" && name != "Finder" {
                self.lastActiveApp = name
            }
        }
        #endif
    }
}
